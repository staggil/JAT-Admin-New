﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Web.Configuration;
using Microsoft.Reporting.WebForms;
using System.Globalization;

namespace JAT.PrivateReport
{
    public partial class reportLabel : System.Web.UI.Page
    {
        private SqlConnection conn;
        private SqlCommand cmd;
        protected void Page_Load(object sender, EventArgs e)
        {
        }
        private void connection()
        {
            var connectionStr = WebConfigurationManager.ConnectionStrings["DefaultConnection2"];
            conn = new SqlConnection(connectionStr.ConnectionString);
        }

        public DataTable SelectSqlTable(string Sqlcmd)
        {
            connection();
            var table = new DataTable();
            string sql = Sqlcmd;
            conn.Open();
            cmd = new SqlCommand(sql, conn);
            SqlDataAdapter dataAdapter = new SqlDataAdapter(cmd);
            dataAdapter.Fill(table);
            conn.Close();
            return table;
        }

        protected void view_Click(object sender, EventArgs e)
        {
            Binddata();
        }

        protected void reset_Click(object sender, EventArgs e)
        {

        }

        private void Binddata()
        {
            DataGrid1.DataSource = GetData().Tables["PrivateReportLabel"].DefaultView;
            DataGrid1.DataBind();
        }

        private DataSet GetData()
        {
            IFormatProvider culture = new CultureInfo("en-US", true);
            connection();
            var DateFrom = datepicker1Input.Value.ToString();
            var DateTo = datepicker2Input.Value.ToString();
            ///this is sql statement which returns records
            ///
                String strSqlSelect = "select d.firstmemberId,d.memberId, d.nameJ, (d.prefixNm + '' + d.nameE) as nameEng, isnull(ha.address, '') as homeAddress, " +
                "isnull(ca.companyNm, '') as companyNm, isnull(ca.address, '') as companyAddress , isnull(sendtype, '$') as sendType " +
                "from privateDetail d " +
                "left join privateAddress ha on d.firstmemberId = ha.memberId and ha.addressType = 1 " +
                "left join privateAddress ca on d.firstmemberId = ca.memberId and ca.addressType = 2 " +
                "left join private p on d.memberId = p.memberId left join privateClub c on d.memberId = c.memberId " +
                "where d.memberStatus = 'A' ";

            if (tbmemberid.Text.Trim() != "")
                strSqlSelect = strSqlSelect + " and d.memberId = '" + tbmemberid.Text.Trim() + "' ";


            if (tbname.Text.Trim() != "")
                strSqlSelect = strSqlSelect + " and d.nameJ like N'"+tbname.Text.Trim() + "%' ";


            if (tbnameE.Text.Trim() != "")
                strSqlSelect = strSqlSelect + " and d.nameE like '"+tbnameE.Text.Trim() + "%' ";

            if (drplstReportTyp.SelectedValue == "Private")
            {
                strSqlSelect = strSqlSelect + " and (p.sendType = '#' or p.sendType = '$') and d.memberType <> '3B' and d.firstmemberId = d.memberId ";
            }
            else if (drplstReportTyp.SelectedValue == "Club" && drplstClub.SelectedValue != "")
            {
                strSqlSelect = strSqlSelect + " and c." + drplstClub.SelectedValue + " = 1 ";
            }
            else if (drplstReportTyp.SelectedValue == "ChangeAddress")
            {
                if (DateFrom != "" && DateTo != "")
                {
                    strSqlSelect = strSqlSelect + " and d.firstmemberId = d.memberId and changeAddressDate between '" + DateFrom + "' and '" + DateTo + "' ";
                }
                else
                    strSqlSelect = strSqlSelect + " and d.firstmemberId = d.memberId ";
            }

            strSqlSelect = strSqlSelect + " order by d.nameE";

            SqlDataAdapter dataAdapter = new SqlDataAdapter(strSqlSelect, conn);
            DataSet myDataSet;
            dataAdapter.SelectCommand.CommandType = CommandType.Text;
            myDataSet = new DataSet();
            dataAdapter.Fill(myDataSet, "PrivateReportLabel");
            return myDataSet;
        }

        protected void print_Click(object sender, EventArgs e)
        {
            DataTable dsCustomers = new DataTable();
            foreach (GridViewRow row in DataGrid1.Rows)
            {
                if ((row.FindControl("chkSelect") as CheckBox).Checked)
                {
                    string test1 = row.Cells[3].Text;
                    string test2 = row.Cells[5].Text;
                    string test3 = row.Cells[6].Text;


                }
                
            }
        }

        protected void DataGrid1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            DataGrid1.PageIndex = e.NewPageIndex;
            Binddata();
        }
    }
}